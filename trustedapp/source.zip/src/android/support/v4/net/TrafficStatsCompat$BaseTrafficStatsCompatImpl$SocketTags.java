// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.net;


// Referenced classes of package android.support.v4.net:
//            TrafficStatsCompat

private static class <init>
{

    public int statsTag;

    private ()
    {
        statsTag = -1;
    }

    statsTag(statsTag statstag)
    {
        this();
    }
}
