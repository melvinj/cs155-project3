// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.view.MenuItem;

// Referenced classes of package android.support.v4.app:
//            ShareCompat

static interface 
{

    public abstract void configureMenuItem(MenuItem menuitem,  );

    public abstract String escapeHtml(CharSequence charsequence);
}
