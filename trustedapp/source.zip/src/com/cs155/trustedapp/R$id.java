// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.cs155.trustedapp;


// Referenced classes of package com.cs155.trustedapp:
//            R

public static final class 
{

    public static final int action_settings = 0x7f080003;
    public static final int btn_read_contacts = 0x7f080001;
    public static final int textView1 = 0x7f080000;
    public static final int text_view_contacts = 0x7f080002;

    public ()
    {
    }
}
